// 1.	WAP to show the use of cout , cin objects and insertion , extraction operators.

#include <iostream>
using namespace std;
int main(){
    string name;
    cout<<"ENTER YOUR NAME : ";
    cin>>name;
    cout<<"Hello "<<name<<endl;
    return 0;
}