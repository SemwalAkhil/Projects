void myFunc(){
    //     cout<<"SIDE X SIDE"<<endl;
    // }