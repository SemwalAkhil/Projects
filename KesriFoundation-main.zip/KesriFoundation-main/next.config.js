/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
}

module.exports = nextConfig

// - name: Static HTML export with Next.js
// run: ${{ steps.detect-package-manager.outputs.runner }} next export
