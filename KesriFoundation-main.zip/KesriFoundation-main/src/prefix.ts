const prefix ='VishakhaFoundation';

export { prefix };